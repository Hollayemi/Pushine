const express = require('express');
const router = express.Router();
const {
    getPerformanceData,
    getRevenueTrend,
    getTopPerformingAccounts
} = require('../controllers/performanceController');

// @route   GET /api/performance
// @desc    Get performance data
// @access  Public (add auth later)
router.get('/', getPerformanceData);

// @route   GET /api/performance/revenue-trend
// @desc    Get revenue trend for charts
// @access  Public (add auth later)
router.get('/revenue-trend', getRevenueTrend);

// @route   GET /api/performance/top-accounts
// @desc    Get top performing accounts
// @access  Public (add auth later)
router.get('/top-accounts', getTopPerformingAccounts);

module.exports = router;