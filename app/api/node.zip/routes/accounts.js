// api/routes/accounts.js
const express = require('express');
const router = express.Router();
const {
    getAllAccounts,
    addAccount,
    updateAccountStatus,
    deleteAccount,
    getDashboardSummary
} = require('../controllers/accountController');

// @route   GET /api/accounts
// @desc    Get all accounts
// @access  Public (add auth later)
router.get('/', getAllAccounts);

// @route   POST /api/accounts
// @desc    Add new account
// @access  Public (add auth later)
router.post('/', addAccount);

// @route   PUT /api/accounts/:id/status
// @desc    Update account status
// @access  Public (add auth later)
router.put('/:id/status', updateAccountStatus);

// @route   DELETE /api/accounts/:id
// @desc    Delete account
// @access  Public (add auth later)
router.delete('/:id', deleteAccount);

// @route   GET /api/accounts/summary
// @desc    Get dashboard summary
// @access  Public (add auth later)
router.get('/summary', getDashboardSummary);

module.exports = router;
