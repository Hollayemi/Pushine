const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema({
    publisherName: {
        type: String,
        required: true,
        trim: true
    },
    networkId: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    status: {
        type: String,
        enum: ['Connected', 'Disconnected', 'Pending'],
        default: 'Pending'
    },
    email: {
        type: String,
        required: true,
        trim: true,
        lowercase: true
    },
    lastSyncAt: {
        type: Date,
        default: Date.now
    },
    isActive: {
        type: Boolean,
        default: true
    },
    // Performance metrics
    dailyRevenue: {
        type: Number,
        default: 0
    },
    dailyImpressions: {
        type: Number,
        default: 0
    },
    eCPM: {
        type: Number,
        default: 0
    },
    ctr: {
        type: Number,
        default: 0
    },
    // Additional metadata
    category: {
        type: String,
        default: 'General'
    },
    country: {
        type: String,
        default: 'US'
    }
}, {
    timestamps: true
});

// Index for faster queries
accountSchema.index({ networkId: 1 });
accountSchema.index({ status: 1 });
accountSchema.index({ email: 1 });

module.exports = mongoose.model('Account', accountSchema);
