const mongoose = require('mongoose');

const performanceSchema = new mongoose.Schema({
    accountId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Account',
        required: true
    },
    networkId: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    revenue: {
        type: Number,
        default: 0
    },
    impressions: {
        type: Number,
        default: 0
    },
    clicks: {
        type: Number,
        default: 0
    },
    eCPM: {
        type: Number,
        default: 0
    },
    ctr: {
        type: Number,
        default: 0
    },
    fillRate: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

// Compound index for efficient queries
performanceSchema.index({ networkId: 1, date: -1 });
performanceSchema.index({ accountId: 1, date: -1 });

module.exports = mongoose.model('Performance', performanceSchema);
