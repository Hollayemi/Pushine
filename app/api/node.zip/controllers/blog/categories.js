
// pages/api/blog/categories.js
// GET /api/blog/categories - Get all categories

export default async function handler(req, res) {
    if (req.method === 'GET') {
        try {
            // In a real app, you'd query your database here
            const categories = [
                'Technology',
                'Design',
                'Backend',
                'Frontend',
                'Mobile',
                'DevOps',
                'Data Science',
                'AI & ML'
            ];

            res.status(200).json({
                success: true,
                data: categories
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                error: 'Failed to fetch categories'
            });
        }
    } else {
        res.setHeader('Allow', ['GET']);
        res.status(405).json({
            success: false,
            error: `Method ${req.method} not allowed`
        });
    }
}