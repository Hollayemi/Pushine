// pages/api/blog/[id].js
// GET /api/blog/[id] - Get single blog post
// PUT /api/blog/[id] - Update blog post
// DELETE /api/blog/[id] - Delete blog post

export default async function handler(req, res) {
    const { id } = req.query;

    if (req.method === 'GET') {
        try {
            // In a real app, you'd query your database here
            // const post = await db.posts.findById(id);

            // Mock data for demonstration
            const mockPost = {
                id: parseInt(id),
                title: "Getting Started with Next.js",
                content: "Next.js is a powerful React framework that enables you to build full-stack web applications. It provides many features out of the box like server-side rendering, static site generation, and API routes.",
                excerpt: "Learn the basics of Next.js and how to build modern web applications.",
                author: "John Doe",
                category: "Technology",
                publishDate: "2024-01-15",
                tags: ["nextjs", "react", "web-development"],
                status: "published",
                views: 245,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };

            if (!mockPost) {
                return res.status(404).json({
                    success: false,
                    error: 'Post not found'
                });
            }

            res.status(200).json({
                success: true,
                data: mockPost
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                error: 'Failed to fetch post'
            });
        }
    } else if (req.method === 'PUT') {
        try {
            const { title, content, excerpt, author, category, tags, status } = req.body;

            // Validate required fields
            if (!title || !content) {
                return res.status(400).json({
                    success: false,
                    error: 'Title and content are required'
                });
            }

            // In a real app, you'd update the database here
            // const updatedPost = await db.posts.findByIdAndUpdate(id, updateData);

            const updatedPost = {
                id: parseInt(id),
                title,
                content,
                excerpt: excerpt || '',
                author: author || 'Anonymous',
                category: category || 'Uncategorized',
                tags: tags || [],
                status: status || 'draft',
                views: 245, // This would come from the database
                publishDate: new Date().toISOString().split('T')[0],
                createdAt: new Date().toISOString(), // This would come from the database
                updatedAt: new Date().toISOString()
            };

            res.status(200).json({
                success: true,
                data: updatedPost,
                message: 'Post updated successfully'
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                error: 'Failed to update post'
            });
        }
    } else if (req.method === 'DELETE') {
        try {
            // In a real app, you'd delete from database here
            // await db.posts.findByIdAndDelete(id);

            res.status(200).json({
                success: true,
                message: 'Post deleted successfully'
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                error: 'Failed to delete post'
            });
        }
    } else {
        res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
        res.status(405).json({
            success: false,
            error: `Method ${req.method} not allowed`
        });
    }
}