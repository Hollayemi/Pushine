const Account = require('../models/Account');
const Performance = require('../models/Performance');

// Get all accounts with latest performance data
const getAllAccounts = async (req, res) => {
    try {
        const accounts = await Account.find({ isActive: true })
            .sort({ createdAt: -1 });

        // Add some demo performance data
        const accountsWithPerformance = accounts.map(account => ({
            ...account.toJSON(),
            dailyRevenue: Math.floor(Math.random() * 450) + 50, // $50-$500
            dailyImpressions: Math.floor(Math.random() * 90000) + 10000, // 10k-100k
            eCPM: (Math.random() * 5.5 + 2.5).toFixed(2), // $2.50-$8.00
            ctr: (Math.random() * 1.7 + 0.8).toFixed(2), // 0.8%-2.5%
            lastSyncAt: new Date()
        }));

        res.status(200).json({
            success: true,
            count: accountsWithPerformance.length,
            data: accountsWithPerformance
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching accounts',
            error: error.message
        });
    }
};

// Add new account (Network ID)
const addAccount = async (req, res) => {
    try {
        const { publisherName, networkId, email, category, country } = req.body;

        // Validate required fields
        if (!publisherName || !networkId || !email) {
            return res.status(400).json({
                success: false,
                message: 'Publisher name, network ID, and email are required'
            });
        }

        // Check if network ID already exists
        const existingAccount = await Account.findOne({ networkId });
        if (existingAccount) {
            return res.status(400).json({
                success: false,
                message: 'Account with this Network ID already exists'
            });
        }

        // Create new account
        const newAccount = new Account({
            publisherName,
            networkId,
            email,
            category: category || 'General',
            country: country || 'US',
            status: 'Connected', // Default to connected for demo
            lastSyncAt: new Date()
        });

        const savedAccount = await newAccount.save();

        // Generate some initial demo performance data
        await generateDemoPerformanceData(savedAccount._id, networkId);

        res.status(201).json({
            success: true,
            message: 'Account added successfully',
            data: savedAccount
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error adding account',
            error: error.message
        });
    }
};

// Update account status
const updateAccountStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!['Connected', 'Disconnected', 'Pending'].includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid status. Must be Connected, Disconnected, or Pending'
            });
        }

        const updatedAccount = await Account.findByIdAndUpdate(
            id,
            {
                status,
                lastSyncAt: new Date()
            },
            { new: true }
        );

        if (!updatedAccount) {
            return res.status(404).json({
                success: false,
                message: 'Account not found'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Account status updated successfully',
            data: updatedAccount
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating account status',
            error: error.message
        });
    }
};

// Delete account
const deleteAccount = async (req, res) => {
    try {
        const { id } = req.params;

        const account = await Account.findByIdAndUpdate(
            id,
            { isActive: false },
            { new: true }
        );

        if (!account) {
            return res.status(404).json({
                success: false,
                message: 'Account not found'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Account deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting account',
            error: error.message
        });
    }
};

// Get dashboard summary
const getDashboardSummary = async (req, res) => {
    try {
        const totalAccounts = await Account.countDocuments({ isActive: true });
        const connectedAccounts = await Account.countDocuments({
            isActive: true,
            status: 'Connected'
        });
        const disconnectedAccounts = await Account.countDocuments({
            isActive: true,
            status: 'Disconnected'
        });

        // Generate demo totals
        const totalRevenue = Math.floor(Math.random() * 5000) + 2000; // $2000-$7000
        const totalImpressions = Math.floor(Math.random() * 900000) + 100000; // 100k-1M
        const avgECPM = (Math.random() * 3 + 4).toFixed(2); // $4.00-$7.00
        const avgCTR = (Math.random() * 0.8 + 1.2).toFixed(2); // 1.2%-2.0%

        res.status(200).json({
            success: true,
            data: {
                totalAccounts,
                connectedAccounts,
                disconnectedAccounts,
                totalRevenue,
                totalImpressions,
                avgECPM: parseFloat(avgECPM),
                avgCTR: parseFloat(avgCTR),
                lastUpdated: new Date()
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching dashboard summary',
            error: error.message
        });
    }
};

// Helper function to generate demo performance data
const generateDemoPerformanceData = async (accountId, networkId) => {
    const performanceData = [];
    const today = new Date();

    // Generate 30 days of historical data
    for (let i = 29; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);

        performanceData.push({
            accountId,
            networkId,
            date,
            revenue: Math.floor(Math.random() * 400) + 100,
            impressions: Math.floor(Math.random() * 80000) + 20000,
            clicks: Math.floor(Math.random() * 800) + 200,
            eCPM: Math.random() * 4 + 3,
            ctr: Math.random() * 1.5 + 1,
            fillRate: Math.random() * 20 + 80
        });
    }

    await Performance.insertMany(performanceData);
};

module.exports = {
    getAllAccounts,
    addAccount,
    updateAccountStatus,
    deleteAccount,
    getDashboardSummary
};