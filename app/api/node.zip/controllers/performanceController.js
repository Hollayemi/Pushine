const Performance = require('../models/Performance');
const Account = require('../models/Account');

// Get performance data for charts
const getPerformanceData = async (req, res) => {
    try {
        const { networkId, days = 30 } = req.query;
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - parseInt(days));

        let query = { date: { $gte: startDate } };
        if (networkId) {
            query.networkId = networkId;
        }

        const performanceData = await Performance.find(query)
            .populate('accountId', 'publisherName')
            .sort({ date: 1 });

        // If no real data, generate demo data
        if (performanceData.length === 0) {
            const demoData = generateDemoChartData(parseInt(days));
            return res.status(200).json({
                success: true,
                data: demoData
            });
        }

        res.status(200).json({
            success: true,
            data: performanceData
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching performance data',
            error: error.message
        });
    }
};

// Get revenue trend for charts
const getRevenueTrend = async (req, res) => {
    try {
        const { days = 30 } = req.query;
        const demoTrendData = [];
        const today = new Date();

        for (let i = parseInt(days) - 1; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);

            demoTrendData.push({
                date: date.toISOString().split('T')[0],
                revenue: Math.floor(Math.random() * 3000) + 1000,
                impressions: Math.floor(Math.random() * 500000) + 100000,
                day: date.toLocaleDateString('en-US', { weekday: 'short' })
            });
        }

        res.status(200).json({
            success: true,
            data: demoTrendData
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching revenue trend',
            error: error.message
        });
    }
};

// Get top performing accounts
const getTopPerformingAccounts = async (req, res) => {
    try {
        const { limit = 5 } = req.query;

        // Demo data for top performing accounts
        const topAccounts = [
            { name: 'TechNews Daily', revenue: 1250, networkId: '12345678' },
            { name: 'Sports Central', revenue: 980, networkId: '87654321' },
            { name: 'Gaming Hub Pro', revenue: 850, networkId: '11223344' },
            { name: 'Fashion Weekly', revenue: 720, networkId: '44332211' },
            { name: 'Food & Lifestyle', revenue: 650, networkId: '55667788' }
        ].slice(0, parseInt(limit));

        res.status(200).json({
            success: true,
            data: topAccounts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching top performing accounts',
            error: error.message
        });
    }
};

// Helper function for demo chart data
const generateDemoChartData = (days) => {
    const data = [];
    const today = new Date();

    for (let i = days - 1; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);

        data.push({
            date: date.toISOString().split('T')[0],
            revenue: Math.floor(Math.random() * 500) + 200,
            impressions: Math.floor(Math.random() * 50000) + 10000,
            clicks: Math.floor(Math.random() * 500) + 100,
            eCPM: (Math.random() * 3 + 4).toFixed(2),
            ctr: (Math.random() * 1.5 + 1).toFixed(2)
        });
    }

    return data;
};

module.exports = {
    getPerformanceData,
    getRevenueTrend,
    getTopPerformingAccounts
};
